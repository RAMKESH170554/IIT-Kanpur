The program file folder contains all the input and programs. 
The output file won't give th output for all the functions at once i.e. it will overwrite previous values.
The output files contains the edited output files for all programs. The graphs are plotted on independently 
as against given in the sample.