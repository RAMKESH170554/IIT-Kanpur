function out = funct1( str,a,b,c )
x=funct2(str,a,b);
y=funct2(str,b,c);

out=( (x-y)/(a-c) );


end

